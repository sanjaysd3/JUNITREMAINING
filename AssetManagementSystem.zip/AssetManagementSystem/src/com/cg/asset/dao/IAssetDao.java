package com.cg.asset.dao;

import java.util.ArrayList;

import com.cg.asset.bean.Asset;
import com.cg.asset.exception.AssetException;

public interface IAssetDao {

	public int addAsset(Asset asset) throws AssetException;

	public ArrayList<Asset> retrieveAllAssetinfo() throws AssetException;

	public int deleteById(int assetId) throws AssetException;

	public ArrayList<Asset> retrieveAllocatedAsset(String statusAllocation) throws AssetException;

	public int updateAssetName(String uname, int id) throws AssetException;
	
	public int updateAssetDesc(String udesc, int id) throws AssetException;
	
	public int updateAssetQuan(int uquan, int id) throws AssetException;
	
	public int updateAssetStat(String ustatus, int id) throws AssetException;

	/*Asset retrieveByAssetName(String assetName);*/

	
	
}
