package com.cg.asset.service;

import java.util.ArrayList;

import com.cg.asset.bean.Asset;
import com.cg.asset.dao.AssetDaoImpl;
import com.cg.asset.dao.IAssetDao;
import com.cg.asset.exception.AssetException;


public class AssetServiceImpl implements IAssetService{
	
	
	IAssetDao assetdao=null;
	
	@Override
	public int addAsset(Asset asset) throws AssetException {
		
		assetdao=new AssetDaoImpl();
		return assetdao.addAsset(asset);
	}
	

	/*@Override
	public Asset retrieveByAssetName(String assetName) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.retrieveByAssetName(assetName);
	}*/

	@Override
	public ArrayList<Asset> retrieveAllAssetinfo() throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.retrieveAllAssetinfo();
	}

	@Override
	public int deleteById(int assetId) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.deleteById(assetId);
	}
	
	@Override
	public ArrayList<Asset> retrieveAllocatedAsset(String statusAllocation) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.retrieveAllocatedAsset(statusAllocation);
	}

	@Override
	public int updateAssetName(String uname, int id) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.updateAssetName(uname, id);
	}

	@Override
	public int updateAssetDesc(String udesc, int id) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.updateAssetDesc(udesc, id);
	}

	@Override
	public int updateAssetQuan(int uquan, int id) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.updateAssetQuan(uquan, id);
	}

	@Override
	public int updateAssetStat(String ustatus, int id) throws AssetException {
		assetdao=new AssetDaoImpl();
		return assetdao.updateAssetStat(ustatus, id);
	}

}
